package com.azure.spring.data.cosmostutorial.emp;

import com.azure.spring.data.cosmos.repository.ReactiveCosmosRepository;
import reactor.core.publisher.Flux;
import org.springframework.stereotype.Repository;

@Repository
public interface ReactiveEmployeeRepository extends ReactiveCosmosRepository<Employee, String> {
    Flux<Employee> findByFirstName(String firstName);
}
